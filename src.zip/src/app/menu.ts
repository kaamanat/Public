export interface menu{
    name: string;
    price: string;
    calories: string;
}