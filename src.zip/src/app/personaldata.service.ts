import{ Injectable } from '@angular/core';
import {kaamanat} from './kaamanat';
@Injectable ({
    providedIn : 'root'
})
export class PersonaldataService {
    loadMyData() : kaamanat{
        const Kaur : kaamanat = 
        {
            studentId : 991504210, name: "Amanat Kaur", loginName :"kaamanat" ,
             campus: "Davis", title:"Kaamanat-A4"
        }
        return Kaur;
    }
    constructor(){}
}

