import { Dish } from './dish';

export const DISH: Dish[] = [
    
    {id:'1', Make:'cake',color:'red',},
    {id:'1', Make:'egg',color:'yellow',},

]