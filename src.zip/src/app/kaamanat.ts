export class kaamanat{
    studentId: number;
    name: string;
    loginName: string;
    campus: string;
    title: string;
}