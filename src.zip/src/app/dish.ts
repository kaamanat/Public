export interface Dish {
    id: number;
    Make: string;
    color: string;
}